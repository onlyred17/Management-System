<!DOCTYPE html>
<?php 
session_start(); 
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="../CSS/main.css" rel="stylesheet">

    <title>Help Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .container-guide {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px;
        }

        .guide-section {
            margin-bottom: 30px;
            background-color: #FFFFFF; 
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
            padding: 20px;
            transition: transform 0.2s;
        }

        .guide-section:hover {
            transform: translateY(-5px);
        }

        .guide-title {
            font-size: 1.75rem; 
            color: #1A2130;
            margin-bottom: 15px;
            border-bottom: 3px solid #83B4FF;
            padding-bottom: 5px;
            font-weight: bold;
        }

        .guide-content {
            font-size: 1.1rem;
            color: #555; 
            line-height: 1.6;
        }

        .guide-content ul {
            margin-left: 20px;
        }

        .guide-content li {
            margin-bottom: 5px; 
            position: relative;
        }

        .guide-content li::before {
            content: "✔"; 
            color: #007B7F;
            position: absolute; 
            left: -20px;
        }

        .get-started-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 25px; 
            border-radius: 5px;
            text-align: center; 
            text-decoration: none;
            font-size: 1.1rem;
            background-color: #007B7F;
            color: white;
            transition: background-color 0.3s, transform 0.2s;
            border: none;
            outline: none;
        }

        .get-started-btn:hover {
            background-color: #005B5D; 
            transform: translateY(-3px);
        }

        .section-header {
            text-align: center;
            margin-top: 20px;
            color: #1A2130;
        }

        @media (max-width: 768px) {
            .guide-section {
                padding: 15px; 
            }

            .get-started-btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
<div class="header">
        <?php include '../HEADER/header.php'; ?>
    </div>
<div class="d-flex">
    <?php include '../SIDEBAR/sidebar.php'; ?>

    <div class="col-md-10 col-12">
        <h1 class="section-header">User Guides</h1>
        
        <div class="container-guide">
            <div class="guide-section">
                <h2 class="guide-title">Getting Started</h2>
                <div class="guide-content">
                    <p>Welcome to the user guide. Here you will find information on how to navigate and use the system effectively.</p>
                    <ul>
                        <li>Login to your account using your email and password.</li>
                        <li>Once logged in, navigate through the sidebar to access different sections.</li>
                    </ul>
                </div>
            </div>
            <div class="guide-section">
                <h2 class="guide-title">Navigating the Dashboard</h2>
                <div class="guide-content">
                    <p>The dashboard is your main hub for monitoring system activity. Here are some key features:</p>
                    <ul>
                        <li><strong>Total Users:</strong> View the total number of registered users in the system.</li>
                        <li><strong>Recent Activities:</strong> Check the latest activities performed within the system.</li>
                        <li><strong>Total Activities:</strong> Get an overview of all activities logged over time.</li>
                        <li><strong>User Growth:</strong> Analyze the growth of user registrations with graphical representations.</li>
                    </ul>
                    <a href="../DASHBOARD/dashboard.php" class="get-started-btn">Get Started</a>
                </div>
            </div>
            <div class="guide-section">
                <h2 class="guide-title">Managing Your Profile</h2>
                <div class="guide-content">
                    <p>To manage your profile, follow these steps:</p>
                    <ul>
                        <li>Open the header profile section and click on "View Profile."</li>
                        <li>You can view your current profile information.</li>
                        <li>To change your password, look for the "Change Password" option in your profile settings.</li>
                        <li>Update your personal information and save changes as needed.</li>
                    </ul>
                    <a href="../PROFILING/edit_profile.php" class="get-started-btn">Get Started</a>
                </div>
            </div>

            <div class="guide-section">
                <h2 class="guide-title">Understanding the Audit Trail</h2>
                <div class="guide-content">
                    <p>The Audit Trail section provides you with the following features:</p>
                    <ul>
                        <li>View user activity logs.</li>
                        <li>Filter logs based on date and user actions.</li>
                        <li>Generate reports based on logged activities.</li>
                    </ul>
                    <a href="../AUDIT_TRAIL/view_details.php" class="get-started-btn">Get Started</a>
                </div>
            </div>
            <div class="guide-section">
                <h2 class="guide-title">Understanding the User Accounts</h2>
                <div class="guide-content">
                    <p>The User Account section provides you with the following features:</p>
                    <ul>
                        <li>View user accounts.</li>
                        <li>Filter logs based on date and user information.</li>
                        <li>Generate reports based on user information.</li>
                    </ul>
                    <a href="../USERS/view_users_details.php" class="get-started-btn">Get Started</a>
                </div>
            </div>
            <div class="guide-section">
                <h2 class="guide-title">Settings: Backup and Restore of Database</h2>
                <div class="guide-content">
                    <p>To manage your database, follow these steps:</p>
                    <ul>
                        <li>Access the settings section from the sidebar.</li>
                        <li>Select the "Backup" option to create a backup of your current database.</li>
                        <li>For restoration, choose the "Restore" option and select the backup file you want to restore from.</li>
                        <li>Follow the prompts to complete the backup or restore process.</li>
                    </ul>
                    <a href="../SETTINGS/settings.php" class="get-started-btn">Get Started</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
