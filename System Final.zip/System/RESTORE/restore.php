<?php
require '../CONNECTION/connection.php';
session_start();

if (isset($_SESSION['audit_email'])) {
    $auditEmail = $_SESSION['audit_email']; 
    $stmt = $conn->prepare("SELECT fname, lname, user_profile_picture FROM user_table WHERE email = ?");
    $stmt->bind_param("s", $auditEmail);
    $stmt->execute();
    $userResult = $stmt->get_result();

    if ($userResult->num_rows > 0) {
        $userData = $userResult->fetch_assoc();
        $userName = $userData['fname'] . ' ' . $userData['lname'];
        $userProfilePicture = $userData['user_profile_picture'] ?: '../PROFILE/default-profile.png'; 
    }
}

$servername = 'localhost';
$username = 'root';
$password = ''; 
$database = 'finalprojectsystem';
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$message = '';
$isSuccess = false;
function restoreDatabase($sqlFile, $conn)
{
    global $message, $isSuccess;
    $sqlContent = file_get_contents($sqlFile);
    $sqlQueries = explode(';', $sqlContent);
    $conn->autocommit(FALSE);
    foreach ($sqlQueries as $query) {
        $query = trim($query); 
        if (!empty($query)) {
            if (!$conn->query($query)) {
                $conn->rollback();
                $message = "Error executing query: " . $conn->error;
                return;
            }
        }
    }
    $conn->commit();
    $message = "Database restored successfully!";
    $isSuccess = true; 
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['sqlFile']) && $_FILES['sqlFile']['error'] == UPLOAD_ERR_OK) {
        $sqlFile = $_FILES['sqlFile']['tmp_name'];
        restoreDatabase($sqlFile, $conn);
    } else {
        $message = "Please upload a valid SQL file.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../CSS/main.css" rel="stylesheet">

    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <title>Restore Database</title>
    <style>
        .container-restore {
            width: 30%;
            background-color: #fff;
            border-radius: 8px;
            padding: 20px;
            margin: 20px auto;
            box-shadow: rgba(0, 0, 0, 0.6) 0px 5px 15px;
        }
        .restore-button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            background-color: #007B7F;

        }

        .restore-button:hover {
            background-color: #005B5D;
            color: black !important;
        }

        input[type="file"] {
            width: 100%;
            box-sizing: border-box;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
    </style>
</head>

<body>
<div class="header">
        <?php include '../HEADER/header.php'; ?>
    </div>
    <div class="d-flex">
        <?php include '../SIDEBAR/sidebar.php';  ?> 
        <div class="col-md-10 col-12">
            <h1 class="text-center mt-4">Restore Database</h1>
            <div class="container-restore">
                <form method="post" enctype="multipart/form-data">
                    <input type="file" name="sqlFile" accept=".sql" required>
                    <button type="submit" name="restore" class="restore-button">Restore Database</button>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messageModalLabel">Restore Status</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?= $message ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <?php if ($isSuccess):?>
    <script>
        $(document).ready(function() {
            $('#messageModal').modal('show');
        });
    </script>
    <?php endif; ?>
</body>
</html>
