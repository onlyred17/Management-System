<?php

// Include the database connection file
require '../CONNECTION/connection.php';

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in; if not, redirect to the login page
if (!isset($_SESSION['email'])) {
    header("Location: ../LOGIN/login.php"); 
    exit(); 
}

// Retrieve user details for the logged-in user
$auditEmail = $_SESSION['email'];
$stmt = $conn->prepare("SELECT fname, lname, user_profile_picture FROM user_table WHERE email = ?");
$stmt->bind_param("s", $auditEmail);
$stmt->execute();
$userResult = $stmt->get_result();

if ($userResult->num_rows > 0) {
    $userData = $userResult->fetch_assoc();
    $userName = $userData['fname'] . ' ' . $userData['lname'];
    $userProfilePicture = $userData['user_profile_picture'] ?: '../PROFILE/default-profile-picture.jpg';
} else {
    // Redirect to login.php if user data is not found
    header("Location: ../LOGIN/login.php");
    exit(); // Ensure no further code is executed
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management System</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-0RQNDsz4CvB2oyKm/XpxkmFCZj1W/2G0zjZ6Y1fzIhFJ4RW6swZWmfRiEWWCU7O45PfkyMQGfswHbYaZwG0wBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-0RQNDsz4CvB2oyKm/XpxkmFCZj1W/2G0zjZ6Y1fzIhFJ4RW6swZWmfRiEWWCU7O45PfkyMQGfswHbYaZwG0wBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
    .profile-pic {
    width: 40px; 
    height: 40px; 
    border-radius: 50%; 
}
.header {
    background-color: #007B7F;
    color: white;
    padding: 15px;
    display: flex; 
    justify-content: space-between; 
    align-items: center;
    position: fixed; 
    top: 0; 
    left: 0px; 
    width: calc(100% - 0px); 
    z-index: 1000; 
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); 
}
.header h2 {
    margin: 0;
    font-size: 1.5rem;
    font-weight: bold;
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.6);
}
.header a {
    color: white;
    text-decoration: none; 
    font-weight: normal;
    margin-left: 10px; 
    padding: 5px 10px; 
    border-radius: 5px;
    transition: background-color 0.3s;
}
.header a:hover {
    background-color: rgba(255, 255, 255, 0.2);
}
.options {
    display: none;
    position: absolute; 
    right: 15px;
    top: 60px; 
    width: 200px;
    background-color: white;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    border-radius: 5px; 
    z-index: 1000;
}
.options a {
    display: flex; 
    align-items: center; 
    padding: 10px;
    color: #1A2130; 
}
.options i {
    margin-right: 10px; 
}
.options a:hover {
    background-color: rgba(131, 180, 255, 0.1); 
}

/* Dark mode styles for options dropdown */
.dark-mode .options {
    background-color: #2B2E33; /* Dark background for dark mode */
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Darker shadow */
}
/* Dark mode for profile */
.dark-mode .profile-section {
    background-color: #2B2E33; /* Dark background */
    color: white;
}
.dark-mode .profile-name {
    color: white;
}
.dark-mode .options a {
    color: #E8F4FA; /* Light text color for dark mode */
}

.dark-mode .options a:hover {
    background-color: rgba(131, 180, 255, 0.2); /* Darker hover effect for better visibility */
}
@media (max-width: 768px) {
    .header h2 {
        font-size: 1.25rem; 
    }
    .profile-pic {
        width: 30px;
        height: 30px; 
    }
}
.header.dark-mode {
    background-color: #005F63;
    color: #E8F4FA; /* Ensure header text is visible in dark mode */
}
.header.dark-mode a {
    color: #E8F4FA; /* Adjust link color in dark mode */
}
.dark-mode {
    background-color: #1A2130;
    color: #E8F4FA;
}
.dark-mode a {
    color: #E8F4FA; /* Set link color in dark mode */
}
.toggle-dark-mode {
    background: none;
    border: none;
    cursor: pointer;
    font-size: 1.5rem;
    color: white;
    transition: transform 0.3s;
}
.toggle-dark-mode i {
    transition: opacity 0.3s ease;
}
.toggle-dark-mode .d-none {
    opacity: 0;
    visibility: hidden; 
}
.toggle-dark-mode .show {
    opacity: 1;
    visibility: visible;
}
.sidebar.dark-mode {
    background-color: #2B2E33;
    color: #E8F4FA;
}
.sidebar.dark-mode a {
    color: #E8F4FA;
}
.profile-container {
    display: flex;
    align-items: center; 
}

/* Dark mode for tables */
.dark-mode table {
    background-color: #2B2E33; 
    color: #E8F4FA; 
}

.dark-mode table tr {
    background-color: #3A3D40;
}

.dark-mode table th {
    background-color: #3A3D40;
    color: #E8F4FA;
}

/* Dark mode for DataTables */
.dark-mode .dataTables_wrapper {
    background-color: #2B2E33;
    color: #E8F4FA;
}

.dark-mode .dataTables_wrapper table {
    background-color: #2B2E33;
    color: #E8F4FA;
}

.dark-mode .dataTables_wrapper table th {
    background-color: #3A3D40;
    color: #E8F4FA;
}

.dark-mode .dataTables_wrapper table td {
    border: 1px solid #444;
    background-color: #2B2E33; 
    color: #E8F4FA; 
}
.dark-mode .dataTables_wrapper table tbody tr:hover {
    background-color: #444;
    color: #E8F4FA;
}

.dark-mode .dataTables_wrapper .dataTables_length,
.dark-mode .dataTables_wrapper .dataTables_filter,
.dark-mode .dataTables_wrapper .dataTables_info,
.dark-mode .dataTables_wrapper .dataTables_paginate {
    color: #E8F4FA;
}

.dark-mode .dataTables_wrapper .dataTables_length select,
.dark-mode .dataTables_wrapper .dataTables_filter input {
    background-color: #3A3D40;
    color: #E8F4FA; 
    border: 1px solid #444;
}
.graph {
    background-color: #fff;
    border: 1px solid #ccc;
    border-radius: 5px;
    margin-top: 15px;
}

.dark-mode .graph {
    background-color: #2B2E33;
    border-color: #444;
}

.dark-mode .card-body {
    background-color: #2B2E33;
    color: #E8F4FA;
}

.dark-mode .user-name {
    color: white;
}

.form-container {
    background-color: white; 
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 6px 30px rgba(0, 0, 0, 0.1); 
    max-width: 900px;
    margin: 30px auto;
}

.profile-box {
    background-color: #E8F4FA;
    border-radius: 10px;
    box-shadow: 0 6px 30px rgba(0, 0, 0, 0.1); 
    margin-bottom: 20px;
    text-align: center;
    border: 1px solid rgba(0, 0, 0, 0.1); 
}

.dark-mode .form-container {
    background-color: #1A2130;
    box-shadow: 0 6px 30px rgba(0, 0, 0, 0.5);
    color: #E8F4FA;
}

.dark-mode .profile-box {
    background-color: #2B2E33;
    box-shadow: 0 6px 30px rgba(0, 0, 0, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.1);
}

.dark-mode .profile-box h5 {
    color: #E8F4FA; 
}

input[type="text"],
input[type="password"],
textarea {
    background-color: white; 
    color: #1A2130;
    border: 1px solid #ccc;
    padding: 10px;
    border-radius: 5px;
    width: 100%;
    margin-bottom: 15px; 
}

.dark-mode input[type="text"],
.dark-mode input[type="password"],
.dark-mode textarea {
    background-color: #3A3D40; 
    color: #E8F4FA;
    border: 1px solid #444; 
}

button {
    background-color: #007B7F; 
    color: white; 
    padding: 10px 15px;
    border: none; 
    border-radius: 5px; 
    cursor: pointer; 
    transition: background-color 0.3s;
}


.dark-mode button {
    background-color: #005F63;
    color: #E8F4FA;
}


button:hover {
    background-color: #005F63;
}

.dark-mode button:hover {
    background-color: #007B7F; 
}


table {
    width: 100%;
    border-collapse: collapse; 
    margin-top: 20px;
}


th {
    background-color: #007B7F; 
    color: white;
    padding: 10px; 
}


tr:nth-child(even) {
    background-color: #f2f2f2;
}


td {
    padding: 10px;
    border: 1px solid #ccc; 
}

.dark-mode th {
    background-color: #005F63; 
}


.dark-mode tr:nth-child(even) {
    background-color: #3A3D40; 
}

.dark-mode td {
    background-color: #2B2E33; 
    color: #E8F4FA;
}

.dark-mode .modal-content {
    background-color: #1A2130; 
    color: #E8F4FA;
}
.dark-mode .guide-section{
    background-color: #2B2E33;

}
.dark-mode .guide-content{
    color: #E8F4FA; 
}
.dark-mode .section-header{
    color:#E8F4FA;
}
.dark-mode .guide-title{
    color:#E8F4FA;
}

.dark-mode .container-backup {
    background-color: #1A2130;
    box-shadow: rgba(255, 255, 255, 0.1) 0px 5px 15px;
}

.dark-mode h2 {
    color: #E8F4FA;
}

.dark-mode .backup-button {
    background-color: #005B5D;
    color: #E8F4FA;
}

.dark-mode .backup-button:hover {
    background-color: #007B7F;
    color: white !important;
}
.dark-mode .container-restore {
    background-color: #1A2130;
    color: #E8F4FA;
    box-shadow: rgba(255, 255, 255, 0.1) 0px 5px 15px;
}

.dark-mode .restore-button {
    background-color: #005B5D;
    color: white;
}

.dark-mode .restore-button:hover {
    background-color: #007B7F;
    color: black !important;
}
</style>


</head>
<body>
<header class="header">
    <h2>Management System</h2>
    <div class="d-flex align-items-center">
        <div class="profile-container d-flex align-items-center">
            <a href="#" id="darkModeToggle" class="toggle-dark-mode">
                <i id="sunIcon" class="fas fa-sun d-none"></i>
                <i id="moonIcon" class="fas fa-moon"></i>
            </a>
            <a href="#" id="profileLink" class="d-flex align-items-center">
                <img src="<?php echo htmlspecialchars($userProfilePicture); ?>" alt="Profile Picture" class="profile-pic">
                <span class="ml-2"><?php echo htmlspecialchars($userName); ?></span>
            </a>
            <div class="options" id="profileOptions">
                <a href="../PROFILING/edit_profile.php" id="viewProfileBtn">
                    <i class="bi bi-person"></i> 
                    View Profile
                </a>
                <a href="../SETTINGS/settings.php">
                    <i class="bi bi-gear"></i> 
                    Settings
                </a>
                <a href="../LOGOUT/logout.php">
                    <i class="bi bi-box-arrow-right"></i> 
                    Logout
                </a>
            </div>
        </div>
    </div>
</header>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $('#profileLink').click(function(e) {
            e.preventDefault(); 
            $('#profileOptions').toggle();
        });
        $('#viewProfileBtn').click(function() {
            $('#profileModal').modal('show'); 
            $('#profileOptions').hide();
        });
        $(document).click(function(event) {
            if (!$(event.target).closest('#profileLink').length) {
                $('#profileOptions').hide();
            }
        });

        $('#darkModeToggle').click(function(e) {
            e.preventDefault();
            $('body').toggleClass('dark-mode');
            $('.header').toggleClass('dark-mode');
            $('.sidebar').toggleClass('dark-mode');
            $('.col-md-10').toggleClass('dark-mode');

            $('#sunIcon').toggleClass('d-none');
            $('#moonIcon').toggleClass('d-none');

            // Optional: Save dark mode preference to local storage
            if ($('body').hasClass('dark-mode')) {
                localStorage.setItem('darkMode', 'enabled');
            } else {
                localStorage.removeItem('darkMode');
            }
        });

        // Check for dark mode preference on page load
        if (localStorage.getItem('darkMode') === 'enabled') {
            $('body').addClass('dark-mode');
            $('.header').addClass('dark-mode');
            $('.sidebar').addClass('dark-mode');
            $('.col-md-10').addClass('dark-mode');
            $('#sunIcon').addClass('d-none');
            $('#moonIcon').removeClass('d-none');
        }
    });
</script>
</body>
</html>
