<?php
require '../CONNECTION/connection.php';
if (!isset($_SESSION['email'])) {
    header("Location: ../LOGIN/login.php"); 
    exit(); 
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$userName = "Guest";
$userProfilePicture = '../PROFILE/default-profile-picture.png';

if (isset($_SESSION['email'])) {
    $auditEmail = $_SESSION['email'];
    $stmt = $conn->prepare("SELECT fname, lname, user_profile_picture FROM user_table WHERE email = ?");
    $stmt->bind_param("s", $auditEmail);
    $stmt->execute();
    $userResult = $stmt->get_result();

    if ($userResult->num_rows > 0) {
        $userData = $userResult->fetch_assoc();
        $userName = $userData['fname'] . ' ' . $userData['lname'];
        $userProfilePicture = $userData['user_profile_picture'] ?: $userProfilePicture;
    }
}
$currentScript = basename($_SERVER['PHP_SELF']);
?>

<!-- Sidebar Toggle Button for smaller screens -->
<button class="btn btn-dark toggle-sidebar" id="sidebarToggle" aria-label="Toggle Sidebar">
    <i class="bi bi-list"></i>
</button>

<!-- Sidebar Navigation -->
 
<nav class="sidebar col-md-2 col-12 d-flex flex-column p-3">
    <div class="text-center management-title">
        <img src="<?php echo htmlspecialchars($userProfilePicture); ?>" alt="Profile Picture" class="rounded-circle" style="width: 80px; height: 80px;">
        <h4 class="user-name"><?php echo htmlspecialchars($userName); ?></h4>
    </div>

    <div class="separator"></div> 

    <div class="nav flex-column">
        <a href="../DASHBOARD/dashboard.php" class="nav-link <?php echo ($currentScript == 'dashboard.php') ? 'active' : ''; ?>">
            <i class="bi bi-house-fill"></i> Dashboard
        </a>
        <a href="../AUDIT_TRAIL/view_details.php" class="nav-link <?php echo ($currentScript == 'view_details.php') ? 'active' : ''; ?>">
            <i class="bi bi-file-person"></i> Audit Trail
        </a>

        <a href="../USERS/view_users_details.php" class="nav-link <?php echo ($currentScript == 'view_users_details.php') ? 'active' : ''; ?>">
            <i class="bi bi-question-circle-fill"></i> Users Account
        </a>

        <a href="../HELP/help.php" class="nav-link <?php echo ($currentScript == 'help.php') ? 'active' : ''; ?>">
            <i class="bi bi-question-circle-fill"></i> Help
        </a>
    </div>
</nav>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<style>
    .sidebar {
        background-color: #E8F4FA; 
        border-right: 1px solid #dee2e6;
        min-height: 100vh; 
        box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        position: fixed; 
        width: 300px; 
        height: 100%; 
        overflow-y: auto; 
        z-index: 1000; 
        top: 80px; /* Adjust to fit below the header */
        transition: transform 0.3s ease;
    }

    .management-title {
        color: #333333; 
        padding: 15px; 
        margin-bottom: 10px; 
        margin-top: 20px; 
    }

    .user-name {
        font-size: 1.5rem; 
        margin-top: 10px; 
        color: #333333;
    }

    .separator {
        height: 6px;
        background-color: #005B5D;
        margin: 5px 0px; 
        margin-bottom: 50px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        width: 100%; 
    }

    .nav {
        margin-top: 20px;
    }

    .nav-link {
        padding: 12px 15px;
        margin: 12px 0;
        font-size: .9rem;
        font-weight: bold; 
        text-transform: uppercase;
        color: #1A2130;
        transition: background-color 0.3s, color 0.3s;
        border-radius: 5px;
    }

    .nav-link:hover {
        background-color: #005B5D; 
        color: white; 
    }

    .nav-link.active {
        background-color: #005B5D; 
        color: white;
    }

    .nav-link i {
        margin-right: 8px;
    }

    /* Hide Sidebar on small screens by default */
    @media (max-width: 750px) {
        .sidebar {
            transform: translateX(-100%);
        }

        .sidebar.show {
            transform: translateX(0);
        }

        .management-title img {
            width: 60px; 
            height: 60px; 
        }

        .user-name {
            font-size: 1.2rem;
        }

        .toggle-sidebar {
    display: flex;
    align-items: center;
    justify-content: center;
    position: fixed;
    top: 70px;
    left: 10px;
    z-index: 1100;
    background-color: #6482AD; /* Matches your palette */
    color: white;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    z-index: 1100; /* Ensure this is lower than the modal */

    font-size: 20px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    transition: transform 0.3s ease, background-color 0.3s ease, box-shadow 0.3s ease;
}


.toggle-sidebar:hover {
    background-color: #7FA1C3; /* Lighter on hover */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
    transform: scale(1.1);
}
/* Bootstrap modal overlay (higher than the toggle) */
.modal-backdrop {
    z-index: 1050;
}
.modal {
    z-index: 1051;
}

/* Hide-toggle class */
.hide-toggle {
    display: none !important;
}
.toggle-sidebar:active {
    transform: rotate(90deg) scale(1.1); /* Adds rotation effect on click */
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.4);
}
    }
</style>

<script>
    document.getElementById('sidebarToggle').addEventListener('click', function() {
        document.querySelector('.sidebar').classList.toggle('show');
    });
    // Hide toggle button when any modal is opened
document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('show.bs.modal', function () {
        document.getElementById('sidebarToggle').classList.add('hide-toggle');
    });
    modal.addEventListener('hidden.bs.modal', function () {
        document.getElementById('sidebarToggle').classList.remove('hide-toggle');
    });
});
</script>
