<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
         body {
            background-color: #E8F4FA;
            display: flex;
            flex-direction: column;
            height: 100vh;
            margin: 0; 
          
        }
        .management-title {
            background-color: transparent; 
            color: #333333;
            padding: 15px;
            font-size: 24px; 
            font-weight: bold; 
            position: absolute;
            top: 10px;
            left: 20px; 
        }
        .login-form {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .register-form {
            width: 100%;
            max-width: 400px;
            background: #FFFFFF;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            color: #333333;
        }
        .register-form h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #1A2130; 
        }
        .btn-custom {
            background-color: #007B7F; 
            color: white;
            width: 100%;
        }
        .btn-custom:hover {
            background-color: #005B5D;
        }
        .login-link {
            position: absolute; 
            top: 20px;
            right: 20px; 
        }
        .btn-link {
            font-size: 1rem;
            text-decoration: none; 
            color: #5A72A0;
            transition: color 0.3s ease; 
        }
        .btn-link:hover {
            color: #1A2130;
        }
        .input-group-append {
            cursor: pointer;
        }
        .input-group-text {
            cursor: pointer; 
        }
        .login-link {
    position: absolute; 
    top: 20px;
    right: 20px;
}

.btn-custom1 {
    background-color: #007B7F; 
    color: white;
    width: auto; 
    padding: 10px 20px; 
    border-radius: 5px; 
    text-align: center; 
    font-size: 1rem; 
    text-decoration: none; 
    transition: background-color 0.3s ease; 
}

.btn-custom1:hover {
    background-color: #005B5D;
}

    </style>
</head>
<body>

<div class="management-title">
    Management System
</div>
<div class="login-link">
    <a href="../LOGIN/login.php" class="btn btn-custom1">Back to Login</a>
</div>
<div class="login-form"> 
<div class="register-form">
    <h2>Create Account</h2>
    <form id="registerForm" action="../register_process.php" method="post">
    <div class="form-group">
            <label for="first_name">First Name</label>
            <input type="text" class="form-control" id="first_name" name="fname" placeholder="Enter first name" >
        </div>
        <div class="form-group">
            <label for="last_name">Last Name</label>
            <input type="text" class="form-control" id="last_name" name="lname" placeholder="Enter last name" >
        </div>
        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" >
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <div class="input-group">
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" >
                <div class="input-group-append">
                    <span class="input-group-text" id="togglePassword">
                        <i class="fas fa-eye" id="eyeIcon"></i>
                    </span>
                </div>
            </div>
            <div id="passwordStrength" class="mt-2">
                <div class="progress">
                    <div id="strengthBar" class="progress-bar" role="progressbar" style="width: 0%;"></div>
                </div>
                <small id="strengthText"></small>
            </div>
        </div>
        <div class="form-group">
            <label for="confirm_password">Confirm Password</label>
            <div class="input-group">
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm password" >
                <div class="input-group-append">
                    <span class="input-group-text" id="toggleConfirmPassword">
                        <i class="fas fa-eye" id="confirmEyeIcon"></i>
                    </span>
                </div>
            </div>
        </div>
        <button type="submit" class="btn btn-custom">Create Account</button>
    </form>
</div>


<div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="messageModalLabel">Notification</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="modalMessageBody">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
    document.getElementById('togglePassword').addEventListener('click', function() {
        const passwordInput = document.getElementById('password');
        const eyeIcon = document.getElementById('eyeIcon');
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            eyeIcon.classList.remove('fa-eye');
            eyeIcon.classList.add('fa-eye-slash');
        } else {
            passwordInput.type = 'password';
            eyeIcon.classList.remove('fa-eye-slash');
            eyeIcon.classList.add('fa-eye');
        }
    });

    document.getElementById('toggleConfirmPassword').addEventListener('click', function() {
        const confirmPasswordInput = document.getElementById('confirm_password');
        const confirmEyeIcon = document.getElementById('confirmEyeIcon');
        if (confirmPasswordInput.type === 'password') {
            confirmPasswordInput.type = 'text';
            confirmEyeIcon.classList.remove('fa-eye');
            confirmEyeIcon.classList.add('fa-eye-slash');
        } else {
            confirmPasswordInput.type = 'password';
            confirmEyeIcon.classList.remove('fa-eye-slash');
            confirmEyeIcon.classList.add('fa-eye');
        }
    });


    function updatePasswordStrength(password) {
    const strengthBar = document.getElementById('strengthBar');
    const strengthText = document.getElementById('strengthText');

    let strength = 0;
    const criteria = [
        { regex: /.{8,}/, message: "At least 8 characters long" }, 
        { regex: /[A-Z]/, message: "At least one uppercase letter" }, 
        { regex: /[a-z]/, message: "At least one lowercase letter" }, 
        { regex: /[0-9]/, message: "At least one number" }, 
        { regex: /[!@#$%^&*(),.?":{}|<>]/, message: "At least one special character" },
    ];

    
    criteria.forEach((criterion) => {
        if (criterion.regex.test(password)) {
            strength++;
        }
    });

   
    if (strength >= 3) { 
        strengthBar.style.width = '80%';
        strengthBar.className = 'progress-bar bg-success';
        strengthText.textContent = 'Strong';
    } else if (strength >= 2) { 
        strengthBar.style.width = '60%';
        strengthBar.className = 'progress-bar bg-info';
        strengthText.textContent = 'Fair';
    } else if (strength >= 1) {
        strengthBar.style.width = '40%';
        strengthBar.className = 'progress-bar bg-warning';
        strengthText.textContent = 'Weak';
    } else { 
        strengthBar.style.width = '20%';
        strengthBar.className = 'progress-bar bg-danger';
        strengthText.textContent = 'Very Weak';
    }
}

    document.getElementById('password').addEventListener('input', function() {
        const password = this.value;
        updatePasswordStrength(password);
    });

    document.getElementById('registerForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const firstName = document.getElementById('first_name').value.trim();
        const lastName = document.getElementById('last_name').value.trim();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();
        const confirmPassword = document.getElementById('confirm_password').value.trim();
        if (!firstName || !lastName || !email || !password || !confirmPassword) {
            showMessageModal('All fields are required.', 'error');
            return;
        }
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            showMessageModal('Please enter a valid email address.', 'error');
            return;
        }
        if (password !== confirmPassword) {
            showMessageModal('Passwords do not match.', 'error');
            return;
        }
        const formData = new FormData(this);
        fetch('register_process.php', {
            method: 'POST',
            body: formData,
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                showMessageModal(data.message, 'success');
                document.getElementById('registerForm').reset();
                strengthBar.style.width = '0%'; 
                strengthText.textContent = ''; 
            } else {
                showMessageModal(data.message, 'error');
            }
        })
        .catch(error => {
            showMessageModal('An error occurred. Please try again.', 'error');
        });
    });
    function showMessageModal(message, type) {
        document.getElementById('modalMessageBody').textContent = message;
        document.getElementById('modalMessageBody').style.color = type === 'success' ? 'green' : 'red'; // Change color based on message type
        $('#messageModal').modal('show');
    }
</script>
</body>
</html>
