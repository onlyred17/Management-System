<?php
// register_process.php

include '../CONNECTION/connection.php'; // Include your database connection

header('Content-Type: application/json'); // Set header for JSON response

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = trim($_POST['fname']);
    $lastName = trim($_POST['lname']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    
    // Validate input
    if (empty($firstName) || empty($lastName) || empty($email) || empty($password)) {
        echo json_encode(["status" => "error", "message" => "All fields are required."]);
        exit;
    }

   
    $stmt = $conn->prepare("SELECT * FROM user_table WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "Email already exists. Please choose another."]);
        exit;
    }


    if (!isPasswordStrong($password)) {
        echo json_encode(["status" => "error", "message" => "Password is too weak. It should contain at least 8 characters, and meet at least 3 of the following criteria: uppercase, lowercase, number, and special character."]);
        exit;
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);


    $usertype = "customer";
    $defaultProfileImage = '../PROFILE/default-profile-picture.jpg';

    $stmt = $conn->prepare("INSERT INTO user_table (fname, lname, email, password, usertype, user_profile_picture) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $firstName, $lastName, $email, $hashedPassword, $usertype, $defaultProfileImage);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Account created successfully!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error: " . $stmt->error]);
    }

    
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method."]);
}


function isPasswordStrong($password) {
    $criteria = [
        '/.{8,}/',
        '/[A-Z]/', 
        '/[a-z]/', 
        '/[0-9]/', 
        '/[!@#$%^&*(),.?":{}|<>]/' 
    ];

    $strengthCount = 0; 

    foreach ($criteria as $criterion) {
        if (preg_match($criterion, $password)) {
            $strengthCount++; 
        }
    }
    
    return $strengthCount >= 3;
}

?>
