-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: finalprojectsystem
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_table`
--

DROP TABLE IF EXISTS `audit_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) NOT NULL,
  `action` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_table`
--

LOCK TABLES `audit_table` WRITE;
/*!40000 ALTER TABLE `audit_table` DISABLE KEYS */;
INSERT INTO `audit_table` VALUES (1,'vjared117@gmail.com','Generated User Account Report','customer','2024-10-24 17:14:18'),(2,'vjared117@gmail.com','LOGGED OUT','customer','2024-10-24 17:14:40'),(3,'vjared117@gmail.com','LOGIN','customer','2024-10-24 17:14:57'),(4,'vjared117@gmail.com','Generated Audit Report','customer','2024-10-24 17:42:28'),(5,'vjared117@gmail.com','LOGGED OUT','customer','2024-10-24 17:42:34'),(6,'jaredsonvicente1771@gmail.com','LOGIN','customer','2024-10-24 17:44:11'),(7,'jaredsonvicente1771@gmail.com','LOGGED OUT','customer','2024-10-24 17:44:59'),(8,'jaredsonvicente1771@gmail.com','LOGIN','customer','2024-10-24 17:45:34'),(9,'jaredsonvicente1771@gmail.com','LOGGED OUT','customer','2024-10-24 17:46:06'),(10,'vjared117@gmail.com','LOGIN','customer','2024-10-27 22:00:31'),(11,'vjared117@gmail.com','LOGGED OUT','customer','2024-10-27 22:01:15'),(12,'vjared117@gmail.com','LOGIN','customer','2024-11-02 14:05:21'),(13,'vjared117@gmail.com','Generated Audit Report','customer','2024-11-02 14:12:28'),(14,'vjared117@gmail.com','Generated Audit Report','customer','2024-11-02 14:12:43'),(15,'vjared117@gmail.com','Generated Audit Report','customer','2024-11-02 14:12:53'),(16,'vjared117@gmail.com','Updated profile information','customer','2024-11-02 16:04:58'),(17,'vjared117@gmail.com','Updated profile picture','customer','2024-11-02 16:05:10'),(18,'vjared117@gmail.com','Updated profile picture','customer','2024-11-02 16:05:12'),(19,'vjared117@gmail.com','LOGGED OUT','customer','2024-11-02 16:08:29'),(20,'vjared117@gmail.com','LOGIN','customer','2024-11-02 16:09:41');
/*!40000 ALTER TABLE `audit_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_table`
--

DROP TABLE IF EXISTS `user_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_table` (
  `userid` int(255) NOT NULL AUTO_INCREMENT,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `usertype` varchar(250) NOT NULL,
  `otp` int(250) NOT NULL,
  `user_profile_picture` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_table`
--

LOCK TABLES `user_table` WRITE;
/*!40000 ALTER TABLE `user_table` DISABLE KEYS */;
INSERT INTO `user_table` VALUES (3,'Jared','Vicente','vjared117@gmail.com','$2y$10$xXBTD2hsBW1KUm1z5KDFU.kjb2zb5PJvW2HCecs6wkhw08JSJqYvS','customer',0,'../PICTURES/abecde2d3530600126186a8e6f3a11f7.jpg','2024-10-20 16:37:01'),(6,'Jared','Vicente','jaredsonvicente1771@gmail.com','$2y$10$30HL4NWpfLZ7v6fle.v.3eOSu4l34ecFinLgEQ0U46qy3tRw/ezI6','customer',0,'../PROFILE/default-profile-picture.jpg','2024-10-24 17:45:15');
/*!40000 ALTER TABLE `user_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-02 16:51:31
