<?php
require '../CONNECTION/connection.php';
session_start();
if (isset($_SESSION['audit_email'])) {
    $auditEmail = $_SESSION['audit_email'];
    $stmt = $conn->prepare("SELECT fname, lname, user_profile_picture FROM user_table WHERE email = ?");
    $stmt->bind_param("s", $auditEmail);
    $stmt->execute();
    $userResult = $stmt->get_result();

    if ($userResult->num_rows > 0) {
        $userData = $userResult->fetch_assoc();
        $userName = $userData['fname'] . ' ' . $userData['lname'];
        $userProfilePicture = $userData['user_profile_picture'] ?: '../PROFILE/default-profile.png';
    }
}

$servername = 'localhost';
$username = 'root';
$password = '';
$database = 'finalprojectsystem';

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function backupDatabase($database, $username, $password)
{
    $backupFile = $database . '.sql';
    $mysqldumpPath = 'C:\\xampp\\mysql\\bin\\mysqldump.exe';
    $command = "$mysqldumpPath --user=$username --password=$password $database > $backupFile";
    exec($command . " 2>&1", $output, $return_var);

    if ($return_var === 0) {
        return $backupFile;
    } else {
        return "Error creating backup: " . implode("\n", $output);
    }
}

$backupMessage = '';
$backupLink = '';

if (isset($_POST['backup'])) {
    $backupResult = backupDatabase($database, $username, $password);
    if (strpos($backupResult, '.sql') !== false) {
        $backupLink = $backupResult;

        $backupMessage = "Backup created successfully!";
    } else {
        $backupMessage = $backupResult;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="../CSS/main.css" rel="stylesheet">
    <title>Database Management</title>
    <style>
        .container-backup {
            width: 40%;
            background-color: #E8F4FA;
            border-radius: 10px;
            padding: 20px;
            margin: 20px auto;
            box-shadow: rgba(0, 0, 0, 0.6) 0px 5px 15px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .backup-button {
            width: 100%;
            padding: 12px;
            background-color: #007B7F;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 10px;
        }

        .backup-button:hover {
            background-color: #005B5D;
            color: black !important;
        }
    </style>
</head>
<body>
<div class="header">
    <?php include '../HEADER/header.php'; ?>
</div>
<div class="d-flex">
    <?php include '../SIDEBAR/sidebar.php'; ?>
    <div class="col-md-10 col-12">
        <h1 class="text-center mt-4">Database Management</h1>
        <div class="container-backup">
            <h2 class="backup-database-title">Backup Database</h2>
            <form method="post">
                <button type="submit" name="backup" class="backup-button">Create Backup</button>
            </form>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="backupModal" tabindex="-1" role="dialog" aria-labelledby="backupModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="backupModalLabel">Backup Status</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php if ($backupMessage): ?>
                    <p><?= $backupMessage ?></p>
                    <?php if ($backupLink): ?>
                        <p><a href="<?= $backupLink ?>" download>Download Backup File</a></p>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php if ($backupMessage): ?>
    <script>
        $(document).ready(function() {
            $('#backupModal').modal('show');
        });
    </script>
<?php endif; ?>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
