<?php
session_start();
if (!isset($_SESSION['email'])) {
    http_response_code(403);
    echo json_encode(["message" => "Unauthorized access."]);
    exit();
}
require '../CONNECTION/connection.php';
if (isset($_POST['userid'])) {
    $id = $_POST['userid'];
    $stmt = $conn->prepare("DELETE FROM user_table WHERE userid = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        echo json_encode(["message" => "User deleted successfully."]);
    } else {
        http_response_code(500);
        echo json_encode(["message" => "Failed to delete the user."]);
    }
    $stmt->close();
} else {
    http_response_code(400);
    echo json_encode(["message" => "Invalid request."]);
}
$conn->close();
?>
