<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Table</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="../CSS/main.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
    <style>
        .new-table-responsive {
            max-height: 400px; 
            overflow-y: auto; 
        }
        table {
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.10); 
        }
        .btn-primary {
            background-color: #007B7F !important; 
            color: white !important;
            border: none !important; 
            outline: none !important;
        }
        .btn-primary:hover {
            background-color: #005B5D !important; 
            color: black !important;
        }
    </style>
</head>
<body>
<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: ../LOGIN/login.php");
    exit();
}

require '../CONNECTION/connection.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userName = "Guest"; 
$userProfilePicture = '../PROFILE/default-profile.png'; 

if (isset($_SESSION['email'])) {
    $auditEmail = $_SESSION['email'];

    $stmt = $conn->prepare("SELECT fname, lname, user_profile_picture FROM user_table WHERE email = ?");
    $stmt->bind_param("s", $auditEmail);
    $stmt->execute();
    $userResult = $stmt->get_result();

    if ($userResult->num_rows > 0) {
        $userData = $userResult->fetch_assoc();
        $userName = $userData['fname'] . ' ' . $userData['lname'];
        $userProfilePicture = $userData['user_profile_picture'] ?: $userProfilePicture; 
    }
}
$stmt = $conn->prepare("SELECT userid, email, fname, lname, user_profile_picture, usertype FROM user_table WHERE email != ? ORDER BY fname");
$stmt->bind_param("s", $auditEmail);
$stmt->execute();
$result_users = $stmt->get_result();
?>
<div class="header">
        <?php include '../HEADER/header.php'; ?>
    </div>
<div class="d-flex flex-wrap">
    <?php include '../SIDEBAR/sidebar.php'; ?>

    <div class="col-md-10 col-12">

        <div class="container mt-4">
            <h1>User Table</h1>

            <div class="mb-3">
                <button class="btn btn-primary" id="generateReportButton">Generate Report</button>
            </div>

            <div class="new-table-responsive">
                <table id="userTable" class="table table-bordered table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th>User ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Profile Picture</th>
                            <th>User Type</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="userTableBody">
                        <?php
                        if ($result_users && $result_users->num_rows > 0) {
                            while ($row = $result_users->fetch_assoc()) {
                                echo "<tr onclick=\"showDetails('" . htmlspecialchars($row['email']) . "', '" . htmlspecialchars($row['fname']) . "', '" . htmlspecialchars($row['lname']) . "', '" . htmlspecialchars($row['user_profile_picture']) . "', '" . htmlspecialchars($row['usertype']) . "')\" style='cursor: pointer;'>";
                                echo "<td>" . htmlspecialchars($row['userid']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['fname'] . ' ' . $row['lname']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                                echo "<td><img src='" . htmlspecialchars($row['user_profile_picture']) . "' alt='Profile Picture' class='img-fluid' style='width: 50px; height: 50px; border-radius: 50%;'></td>";
                                echo "<td>" . htmlspecialchars($row['usertype']) . "</td>";
                                echo "<td><button class='btn btn-danger' onclick='confirmDelete(event, " . htmlspecialchars($row['userid']) . ")'>Delete</button></td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='6' class='text-center'>No users found.</td></tr>"; 
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="modal fade" id="detailsModal" tabindex="-1" aria-labelledby="detailsModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="detailsModalLabel">User Details</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body text-center">
                        <img id="modalProfilePicture" src="" alt="Profile Picture" class="img-fluid rounded-circle mb-3" style="width: 120px; height: 120px; border: 2px solid #83B4FF;">
                        <h6 class="font-weight-bold">User Information</h6>
                        <p><strong>Name:</strong> <span id="modalName"></span></p>
                        <p><strong>User:</strong> <span id="modalEmail"></span></p>
                        <p><strong>User Type:</strong> <span id="modalUserType"></span></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="deleteConfirmationModal" tabindex="-1" aria-labelledby="deleteConfirmationModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirm Deletion</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body text-center">
                        <p>Are you sure you want to delete this user?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-danger" id="confirmDeleteButton">Delete</button>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
        <script>
            let deleteId;

            $(document).ready(function() {
                const table = $('#userTable').DataTable();

                window.showDetails = function(email, firstName, lastName, profilePicture, userType) {
                    $('#modalProfilePicture').attr('src', profilePicture);
                    $('#modalName').text(firstName + ' ' + lastName);
                    $('#modalEmail').text(email);
                    $('#modalUserType').text(userType);
                    $('#detailsModal').modal('show');
                };
                window.confirmDelete = function(event, id) {
                    event.stopPropagation(); 
                    deleteId = id;
                    $('#deleteConfirmationModal').modal('show');
                };

                $('#confirmDeleteButton').click(function() {
    if (deleteId) {
        $.ajax({
            url: 'delete_user.php',
            type: 'POST',
            data: { userid: deleteId },
            success: function(response) {
                location.reload();
            },
            error: function(xhr, status, error) {
                console.error('Delete failed: ', error); 
            }
        });
    }
});
                $('#generateReportButton').click(function() {
                    var searchTerm = table.search();
                    var url = '../USERS/generate_report.php';
                    if (searchTerm) {
                        url += (url.includes('?') ? '&' : '?') + 'search=' + encodeURIComponent(searchTerm);
                    }
                window.open(url, '_blank');
            });
        });
        </script>
    </div>
</div>
</body>
</html>
