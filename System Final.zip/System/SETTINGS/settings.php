<?php
require '../CONNECTION/connection.php';
session_start();
if (isset($_SESSION['audit_email'])) {
    $auditEmail = $_SESSION['audit_email']; 
    $stmt = $conn->prepare("SELECT fname, lname, user_profile_picture FROM user_table WHERE email = ?");
    $stmt->bind_param("s", $auditEmail);
    $stmt->execute();
    $userResult = $stmt->get_result();

    if ($userResult->num_rows > 0) {
        $userData = $userResult->fetch_assoc();
        $userName = $userData['fname'] . ' ' . $userData['lname'];
        $userProfilePicture = $userData['user_profile_picture'] ?: '../PROFILE/default-profile.png';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-0RQNDsz4CvB2oyKm/XpxkmFCZj1W/2G0zjZ6Y1fzIhFJ4RW6swZWmfRiEWWCU7O45PfkyMQGfswHbYaZwG0wBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="../CSS/main.css" rel="stylesheet">
    <style>
      .container {
            margin-top: 30px; 
            
        }

        h2 {
            font-weight: bold;
            margin-bottom: 30px;
            text-align: center;
            font-size: 2rem;
        }

        .settings-section {
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }

        .button-container {
            display: flex; 
            flex-direction: column; 
            align-items: center;
            gap: 20px;
        }

        .custom-button {
            padding: 15px 25px;
            border-radius: 5px; 
            display: flex;
            align-items: center;
            font-size: 1.1rem;
            text-transform: uppercase;
            transition: background-color 0.2s, transform 0.2s; 
            width: 100%;
            max-width: 300px;
            color: white !important;
            background-color: #007B7F;
            text-decoration: none;
        }
        .button-container .custom-button {
            background-color: #007B7F;
        }

        .custom-button:hover {
            background-color: #005B5D;
            color: black !important;
        }
    </style>
</head>
<body>
<div class="header">
        <?php include '../HEADER/header.php'; ?>
</div>
<div class="d-flex">
    <?php include '../SIDEBAR/sidebar.php'; ?>
    <div class="col-md-10 col-12"> 
        <div class="container">
            <h2>Settings</h2>
            <div class="settings-section">
                <div class="button-container">
                    <a href="../BACKUP/backup.php" class="btn custom-button">
                        <i class="fas fa-database button-icon"></i>Backup
                    </a>
                    <a href="../RESTORE/restore.php" class="btn custom-button">
                        <i class="fas fa-undo button-icon"></i>Restore
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>