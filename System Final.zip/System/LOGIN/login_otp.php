<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: login.php'); 
    exit();
}
require '../PHPMailer/PHPMailer.php';
require '../PHPMailer/SMTP.php';
require '../PHPMailer/Exception.php';
require "../CONNECTION/connection.php"; 

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$errorMessage = '';

function sendOtp($email, $otp) {
    $mail = new PHPMailer();

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp-relay.brevo.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'jaredsonvicente1771@gmail.com';
        $mail->Password = 'kWV40qgL9B7DGT5P';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->setFrom('no-reply@example.com', 'Your System');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = "Your OTP Code";
        $mail->Body = "Your OTP code is: <strong>$otp</strong><br>Please enter this code to verify your account.";
        $mail->send();
    } catch (Exception $e) {
        error_log("Mailer Error: " . $mail->ErrorInfo);
        return false;
    }
    return true;
}
if (!isset($_SESSION['otp'])) {
    $_SESSION['otp'] = rand(100000, 999999);
    sendOtp($_SESSION['email'], $_SESSION['otp']); 
    $_SESSION['otp_timer'] = time() + 60; 
}


if (isset($_POST['resend'])) {
    $_SESSION['otp'] = rand(100000, 999999); 
    sendOtp($_SESSION['email'], $_SESSION['otp']); 
    $_SESSION['otp_timer'] = time() + 60;
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['otp'])) {
    $inputOtp = isset($_POST['otp']) ? trim($_POST['otp']) : '';
  
    if ($inputOtp == $_SESSION['otp']) {
        unset($_SESSION['otp']);
        $email = $_SESSION['email'];
        $action = 'LOGIN';
        $usertype = isset($_SESSION['usertype']) ? $_SESSION['usertype'] : 'Unknown';
        $stmt = $conn->prepare("INSERT INTO audit_table (email, action, usertype, date_time) VALUES (?, ?, ?, NOW())");
        if ($stmt === false) {
            error_log("Error preparing statement: " . $conn->error);
            $errorMessage = 'Failed to log the audit entry.';
        } else {
            $stmt->bind_param("sss", $email, $action, $usertype);
            if (!$stmt->execute()) {
                error_log("Error executing statement: " . $stmt->error);
                $errorMessage = 'Failed to log the audit entry.';
            }
            $stmt->close();
        }
        if (empty($errorMessage)) {
            header('Location: ../DASHBOARD/dashboard.php');
            exit();
        }
    } else {
        $errorMessage = 'Invalid OTP. Please try again.';
    }
}
$remainingTime = isset($_SESSION['otp_timer']) ? $_SESSION['otp_timer'] - time() : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
       body {
            background-color: #E8F4FA;
            display: flex;
            flex-direction: column;
            height: 100vh;
            margin: 0;
        }
        .management-title {
            background-color: transparent;
            color: #1A2130;
            padding: 15px;
            font-size: 24px;
            font-weight: bold;
            position: absolute;
            top: 10px;
            left: 20px;
        }
        .container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .otp-form {
            width: 100%;
            max-width: 400px;
            background: #FFFFFF;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            color: #333333;
        }
        .otp-form h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #1A2130;
        }
        .btn-custom {
            background-color: #007B7F; 
            color: white;
            width: 100%;
        }
        .btn-custom:hover {
            background-color: #005B5D;
        }
        #countdown {
            font-size: 1rem;
            margin-top: 10px;
            text-align: center;
        }
        .btn-link {
            display: block;
            margin-top: 10px;
            text-align: center;
            font-size: 1rem;
            text-decoration: none;
            color: #5A72A0; 
            transition: color 0.3s ease; 
        }
        .btn-link:hover {
            color: #1A2130;
        }
        .btn-secondary{
            width: 100%;
        }
        
    </style>
    <script>
        function startTimer(duration) {
            var timer = duration, seconds;
            var countdownElement = document.getElementById('countdown');

            var interval = setInterval(function () {
                seconds = parseInt(timer % 60, 10);
                seconds = seconds < 10 ? "0" + seconds : seconds;
                countdownElement.textContent = seconds + " seconds remaining";
                if (--timer < 0) {
                    clearInterval(interval);
                    countdownElement.textContent = ""; 
                    document.getElementById('resendButton').disabled = false; 
                }
            }, 1000);
        }
        window.onload = function () {
            var remainingTime = <?php echo max(0, $remainingTime); ?>;
            if (remainingTime > 0) {
                document.getElementById('resendButton').disabled = true; 
                startTimer(remainingTime);
            }
        };
    </script>
</head>
<body>
    <div class="management-title">
        Management System
    </div>
    <div class="container mt-5">
        <div class="otp-form">
            <h2>Verify OTP</h2>
            <?php if (!empty($errorMessage)): ?>
                <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
            <?php endif; ?>
            <form method="post">
                <div class="form-group">
                    <label for="otp">Enter OTP</label>
                    <input type="text" class="form-control" id="otp" name="otp" required>
                </div>
                <button type="submit" class="btn btn-custom">Verify OTP</button>
            </form>
            <div id="countdown"></div>
            <form method="post">
                <button type="submit" name="resend" id="resendButton" class="btn btn-secondary" <?php if ($remainingTime > 0) echo 'disabled'; ?>>Resend OTP</button>
            </form>
            <a href="login.php" class="btn btn-link">Back to Login</a>
        </div>
    </div>
</body>
</html>
