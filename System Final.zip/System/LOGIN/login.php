<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #E8F4FA; 
            display: flex;
            flex-direction: column;
            height: 100vh;
            margin: 0;
            transition: background-color 0.3s, color 0.3s;
        }
        body.dark-mode {
            background-color: #1A2130; 
            color: #FFFFFF; 
        }
        .management-title {
            background-color: transparent;
            color: #333333;
            padding: 15px;
            font-size: 24px;
            font-weight: bold;
            position: absolute;
            top: 10px; 
            left: 20px;
        }
        .dark-mode .management-title {
            color: #FDFFE2; 
        }
        .login-form {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .form-container {
            width: 100%;
            max-width: 400px;
            background: #FFFFFF; 
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            color: #333333;
            transition: background 0.3s, color 0.3s;
        }
        .dark-mode .form-container {
            background: #2C2F36; 
            color: #FFFFFF;
        }
        .login-form h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333333;
        }
        .dark-mode .login-form h2 {
            color: #FDFFE2; 
        }
        .btn-custom {
            background-color: #007B7F; 
            color: white;
            width: 100%;
        }
        .btn-custom:hover {
            background-color: #005B5D; 
        }
        .create-account {
            text-align: center;
            margin-top: 20px;
        }
        .create-account a {
            color: #007B7F; 
            text-decoration: none; 
        }
        .dark-mode .create-account a {
            color: #FDFFE2; 
        }
        .create-account a:hover {
            text-decoration: underline;
        }
        .input-group-append {
            cursor: pointer;
        }
        .toggle-theme {
            position: absolute;
            top: 15px;
            right: 20px;
            cursor: pointer;
            font-size: 24px;
            color: #007B7F;
            transition: color 0.3s;
        }
        .dark-mode .toggle-theme {
            color: #FDFFE2; 
        }
    </style>
</head>
<body>

<div class="management-title">
    Management System
</div>
<div class="toggle-theme" onclick="toggleDarkMode()">
    <i class="fas fa-sun" id="themeIcon"></i>
</div>

<div class="login-form">
    <div class="form-container">
        <h2>Login</h2>
        <form id="loginForm" method="post">
            <div class="form-group">
                <label for="email">Email address</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <div class="input-group">
                    <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                    <div class="input-group-append" onclick="togglePassword()">
                        <span class="input-group-text" id="passwordEye">
                            <i class="fas fa-eye" id="eyeIcon"></i>
                        </span>
                    </div>
                </div>
            </div>
            <button type="button" class="btn btn-custom" onclick="submitForm()">Login</button>
        </form>

        <div class="create-account">
            <p>Don't have an account? <a href="../SIGNUP/signup.php">Create Account</a></p>
        </div>
    </div>
</div>

<div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="errorModalLabel">Error</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p id="errorMessage">Error Message</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

<script>
    function submitForm() {
        var email = document.getElementById('email').value;
        var password = document.getElementById('password').value;
        $.ajax({
            type: 'POST',
            url: 'verify_login.php', 
            data: { email: email, password: password },
            dataType: 'json',
            success: function(response) {
                console.log("Response from server:", response); 
                if (response.success) {
                    window.location.href = '../LOGIN/login_otp.php';
                } else {
                    document.getElementById('errorMessage').textContent = response.error;
                    $('#errorModal').modal('show');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error("AJAX error: " + textStatus + ": " + errorThrown);
                document.getElementById('errorMessage').textContent = 'An error occurred. Please try again.';
                $('#errorModal').modal('show');
            }
        });
    }
    function togglePassword() {
        var passwordInput = document.getElementById('password');
        var eyeIcon = document.getElementById('eyeIcon');
        if (passwordInput.type === "password") {
            passwordInput.type = "text";
            eyeIcon.classList.remove("fa-eye");
            eyeIcon.classList.add("fa-eye-slash");
        } else {
            passwordInput.type = "password";
            eyeIcon.classList.remove("fa-eye-slash");
            eyeIcon.classList.add("fa-eye");
        }
    }
    function toggleDarkMode() {
        document.body.classList.toggle("dark-mode");
        var themeIcon = document.getElementById('themeIcon');
        themeIcon.classList.toggle("fa-sun");
        themeIcon.classList.toggle("fa-moon");
    }
</script>
</body>
</html>
