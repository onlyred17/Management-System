<?php
session_start();

require "../CONNECTION/connection.php"; 
if ($conn->connect_error) {
    error_log("Connection failed: " . $conn->connect_error);
    echo json_encode(['error' => 'Database connection failed.']);
    exit();
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['otp'])) {
        $otp = trim($_POST['otp']);
        if (isset($_SESSION['otp'])) {
            if ($otp === $_SESSION['otp']) {
                unset($_SESSION['otp']);
                echo json_encode(['success' => true]);
                exit();
            } else {
                echo json_encode(['error' => 'Invalid OTP.']);
                exit();
            }
        } else {
            echo json_encode(['error' => 'OTP not generated.']);
            exit();
        }
    } else {
        echo json_encode(['error' => 'OTP is required.']);
        exit();
    }
} else {
    echo json_encode(['error' => 'Invalid request. Please use POST method.', 'method' => $_SERVER['REQUEST_METHOD']]);
    exit();
}
?>
