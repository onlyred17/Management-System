<?php
require '../CONNECTION/connection.php';
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/PHPMailer.php';
require '../PHPMailer/SMTP.php';
require '../PHPMailer/Exception.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    if (empty($email) || empty($password)) {
        echo json_encode(['error' => 'Please fill in all fields.']);
        exit();
    }
    $stmt = $conn->prepare("SELECT password, usertype FROM user_table WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();


    if ($result->num_rows > 0) {
 
        $row = $result->fetch_assoc();
        $hashed_password = $row['password'];

  
        if (password_verify($password, $hashed_password)) {

            $_SESSION['email'] = $email; 
            $_SESSION['usertype'] = $row['usertype'];
            $otp = rand(100000, 999999);
            $_SESSION['otp'] = $otp;

            $mail = new PHPMailer();
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp-relay.brevo.com'; 
                $mail->SMTPAuth = true;
                $mail->Username = 'jaredsonvicente1771@gmail.com';
                $mail->Password = 'kWV40qgL9B7DGT5P'; 
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;
                $mail->setFrom('no-reply@example.com', 'Your System');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = "Your OTP Code";
                $mail->Body = "Dear User,<br><br>Your OTP code is: <strong>$otp</strong><br>Please use this code to complete your login process.<br>";
                $mail->send();

           
                echo json_encode(['success' => true]);
                exit();
            } catch (Exception $e) {
               
                echo json_encode(['error' => 'Error sending OTP email: ' . $mail->ErrorInfo]);
                exit();
            }
        } else {
         
            echo json_encode(['error' => 'Invalid email or password.']);
            exit();
        }
    } else {
   
        echo json_encode(['error' => 'Invalid email or password.']);
        exit();
    }
} else {

    echo json_encode(['error' => 'Invalid request.']);
    exit();
}
?>
