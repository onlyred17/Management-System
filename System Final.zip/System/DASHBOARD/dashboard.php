<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="../CSS/main.css" rel="stylesheet">
    <style>
        .card-custom-size {
            height: 300px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.6);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .card-custom-size:hover {
            transform: scale(1.05); 
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.8);
        }
        table {
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.6);
        }
    </style>
</head>
<body>
<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: ../LOGIN/login.php");
    exit();
}
require '../CONNECTION/connection.php';
$sql_total_users = "SELECT COUNT(*) as total_users FROM user_table";
$result_total_users = $conn->query($sql_total_users);
$total_users = 0; 

if ($result_total_users && $row = $result_total_users->fetch_assoc()) {
    $total_users = $row['total_users']; 
}
$counts = []; 
$total_activities = 0; 
$sql_activity_counts = "SELECT action, COUNT(*) as count FROM audit_table GROUP BY action";
$result_activity_counts = $conn->query($sql_activity_counts);

if ($result_activity_counts && $result_activity_counts->num_rows > 0) {
    while ($row = $result_activity_counts->fetch_assoc()) {
        $actions[] = htmlspecialchars($row['action']); 
        $counts[] = (int)$row['count']; 
    }
    $total_activities = array_sum($counts);
} else {
    $total_activities = 0;
}

$logged_in_email = $_SESSION['email']; 
$sql_recent_activities = "SELECT email, action, date_time FROM audit_table WHERE email = '$logged_in_email' ORDER BY date_time DESC LIMIT 5"; 
$result_recent_activities = $conn->query($sql_recent_activities);

$sql_user_growth = "SELECT DATE(created_at) as date, COUNT(*) as user_count FROM user_table GROUP BY DATE(created_at) ORDER BY DATE(created_at)"; 
$result_user_growth = $conn->query($sql_user_growth);

$user_growth_dates = [];
$user_growth_counts = [];
$total_new_users = 0; 
if ($result_user_growth && $result_user_growth->num_rows > 0) {
    while ($row = $result_user_growth->fetch_assoc()) {
        $user_growth_dates[] = htmlspecialchars($row['date']);
        $new_users_count = (int)$row['user_count'];
        $user_growth_counts[] = $new_users_count; 
        $total_new_users += $new_users_count; 
    }
}

$sql_most_common_activities = "SELECT action, COUNT(*) as count FROM audit_table GROUP BY action ORDER BY count DESC LIMIT 5";
$result_most_common_activities = $conn->query($sql_most_common_activities);

$common_activity_labels = [];
$common_activity_counts = [];

if ($result_most_common_activities && $result_most_common_activities->num_rows > 0) {
    while ($row = $result_most_common_activities->fetch_assoc()) {
        $common_activity_labels[] = htmlspecialchars($row['action']);
        $common_activity_counts[] = (int)$row['count']; 
    }
}

$conn->close();
?>
 <div class="header">
        <?php include '../HEADER/header.php'; ?>
    </div>
<div class="d-flex">
    <?php include '../SIDEBAR/sidebar.php';?>
    <div class="col-md-10 col-12">
        <div class="container mt-4">
            <h1>Dashboard</h1>
            <div class="row">
                <div class="col-md-4 col-sm-6 mb-4">
                    <div class="card card-custom-size">
                        <div class="card-body">
                            <h5 class="card-title">Total Users</h5>
                            <p class="card-text" style="font-size: 2rem; font-weight: bold;"><?php echo htmlspecialchars($total_users); ?></p> 
                            <canvas id="userChart" width="200" height="100"></canvas>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 col-sm-6 mb-4">
                    <div class="card card-custom-size">
                        <div class="card-body">
                            <h5 class="card-title">Total Activities</h5>
                            <p class="card-text" style="font-size: 2rem; font-weight: bold;"><?php echo $total_activities; ?></p> 
                            <canvas id="activityChart" width="200" height="100"></canvas>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-6 mb-4">
                    <div class="card card-custom-size">
                        <div class="card-body">
                            <h5 class="card-title">User Growth</h5>
                            <p class="card-text" style="font-size: 1.5rem; font-weight: bold;">Total New Users: <?php echo $total_new_users; ?></p> 
                            <canvas id="userGrowthChart" width="200" height="100"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-4">
                <h4>Your Recent Activities</h4>
                <table class="table table-bordered table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th>User</th>
                            <th>Action</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result_recent_activities && $result_recent_activities->num_rows > 0) {
                            while ($row = $result_recent_activities->fetch_assoc()) {
                                echo "<tr>"; 
                                echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['action']) . "</td>"; 
                                echo "<td>" . htmlspecialchars($row['date_time']) . "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3' class='text-center'>No recent activities found.</td></tr>"; 
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    var ctxUserGrowth = document.getElementById('userGrowthChart').getContext('2d');
    var userGrowthChart = new Chart(ctxUserGrowth, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($user_growth_dates); ?>,
            datasets: [{
                label: 'New Users',
                data: <?php echo json_encode($user_growth_counts); ?>,
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                fill: true,
                tension: 0.1
            }]
        }
    });
    var ctxUser = document.getElementById('userChart').getContext('2d');
    var userChart = new Chart(ctxUser, {
        type: 'bar',
        data: {
            labels: ['Total Users'],
            datasets: [{
                label: 'Users',
                data: [<?php echo $total_users; ?>],
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        }
    });

    var ctxActivities = document.getElementById('activityChart').getContext('2d');
    var activityChart = new Chart(ctxActivities, {
        type: 'bar',
        data: {
            labels: ['Total Activities'],
            datasets: [{
                label: 'Activities',
                data: [<?php echo $total_activities; ?>],
                backgroundColor: 'rgba(255, 206, 86, 0.2)',
                borderColor: 'rgba(255, 206, 86, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
</body>
</html>
