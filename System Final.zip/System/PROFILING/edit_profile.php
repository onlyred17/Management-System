<?php
session_start();
include '../CONNECTION/connection.php'; // Include your database connection

// Assuming user ID (email) is stored in session after login
$user_email = $_SESSION['email'];

// Fetch current user information from the database
$query = "SELECT fname, lname, email, user_profile_picture, usertype FROM user_table WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $user_email); // Bind email as string
$stmt->execute();
$result = $stmt->get_result();
$current_user = $result->fetch_assoc();

$feedback_message = isset($_SESSION['feedback_message']) ? $_SESSION['feedback_message'] : '';
$feedback_type = isset($_SESSION['feedback_type']) ? $_SESSION['feedback_type'] : '';

// Clear feedback messages from the session after displaying them
unset($_SESSION['feedback_message']);
unset($_SESSION['feedback_type']);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_info'])) {
        // Update user information
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];

        // Check if all required fields are filled
        if (empty($first_name) || empty($last_name)) {
            $feedback_message = 'All fields are required!';
            $feedback_type = 'error';
        } else {
            // Update user information
            $update_query = "UPDATE user_table SET fname = ?, lname = ? WHERE email = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("sss", $first_name, $last_name, $user_email);

            // Execute update and set feedback message
            if ($update_stmt->execute()) {
                // Insert into audit trail with date_time and user_type
                $audit_query = "INSERT INTO audit_table (email, action, date_time, usertype) VALUES (?, ?, NOW(), ?)";
                $audit_stmt = $conn->prepare($audit_query);
                $action = 'Updated profile information';
                $user_type = $current_user['usertype']; // Get user_type from current user
                $audit_stmt->bind_param("sss", $user_email, $action, $user_type);
                $audit_stmt->execute();

                $feedback_message = 'Profile information updated successfully!';
                $feedback_type = 'success';
            } else {
                $feedback_message = 'Failed to update profile information!';
                $feedback_type = 'error';
            }
        }
    } elseif (isset($_POST['update_picture'])) {
        // Handle profile picture upload if a file was selected
        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
            $target_dir = "../PICTURES/";
            $target_file = $target_dir . basename($_FILES["profile_picture"]["name"]);
            move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file);

            // Update query including the profile picture path
            $update_query = "UPDATE user_table SET user_profile_picture = ? WHERE email = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("ss", $target_file, $user_email);

            // Execute update and set feedback message
            if ($update_stmt->execute()) {
                // Insert into audit trail with date_time and user_type
                $audit_query = "INSERT INTO audit_table (email, action, date_time, usertype) VALUES (?, ?, NOW(), ?)";
                $audit_stmt = $conn->prepare($audit_query);
                $action = 'Updated profile picture';
                $user_type = $current_user['usertype']; // Get user_type from current user
                $audit_stmt->bind_param("sss", $user_email, $action, $user_type);
                $audit_stmt->execute();

                $feedback_message = 'Profile picture updated successfully!';
                $feedback_type = 'success';
            } else {
                $feedback_message = 'Failed to update profile picture!';
                $feedback_type = 'error';
            }
        } else {
            $feedback_message = 'No file uploaded!';
            $feedback_type = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="../CSS/main.css" rel="stylesheet"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #F4F6F9; 
            font-family: 'Arial', sans-serif;
        }
        .btn-primary {
            background-color: #007B7F !important; 
            color: white !important;
            transition: background-color 0.3s, color 0.3s; 
            border: none !important;
            outline: none !important; 
        }
        .btn-primary:hover {
            background-color: #005B5D !important; 
            color: black !important;
        }
        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 6px 30px rgba(0, 0, 0, 0.1); 
            max-width: 900px;
            margin: 30px auto;
        }
        .profile-box {
            background-color: #E8F4FA;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 6px 30px rgba(0, 0, 0, 0.1); 
            margin-bottom: 20px;
            text-align: center;
            border: 1px solid rgba(0, 0, 0, 0.1); 
        }
        .profile-box h5 {
            margin-bottom: 15px;
            font-size: 22px; 
            font-weight: bold;
            color: #5A72A0; 
        }
        .divider {
            border: none;
            border-top: 3px solid #83B4FF;
            margin: 10px 0;
        }
        .profile-pic-container {
            margin-bottom: 10px;
        }
        .profile-box .profile-pic {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            max-width: 100%;
            border: 3px solid #83B4FF; 
        }
        .form-group label {
            font-weight: bold;
        }
        .form-control, .form-control-file {
            border-radius: 5px;
        }
        .modal-content {
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
<div class="header">
        <?php include '../HEADER/header.php'; ?>
    </div>
<div class="d-flex flex-wrap">
    <?php include '../SIDEBAR/sidebar.php'; ?>
    <div class="col-md-10 col-12">
       
        
        <div class="container mt-4">
            <h1 class="mb-4 text-center">Update Profile</h1>

            <div class="form-container row">
                <div class="col-md-4">
                    <div class="profile-box">
                        <h5>Profile Information</h5>
                        <hr class="divider">
                        <div class="profile-pic-container">
                            <?php if ($current_user['user_profile_picture']): ?>
                                <img src="<?php echo $current_user['user_profile_picture']; ?>" alt="Profile Picture" class="profile-pic">
                            <?php else: ?>
                                <img src="../PICTURES/default_profile.png" alt="Default Profile Picture" class="profile-pic">
                            <?php endif; ?>
                            <h4>JPG or PNG no larger than 5 MB</h4>
                        </div>
                    </div>
                    <div class="profile-box mt-4">
                        <h5>Change Password</h5>
                        <hr class="divider">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#changePasswordModal">
                            Change Password
                        </button>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="profile-box">
                        <h5>Update Information</h5>
                        <hr class="divider">
                        <form method="POST" action="">
                            <div class="form-group">
                                <label for="first_name">First Name:</label>
                                <input type="text" name="first_name" id="first_name" class="form-control" value="<?php echo htmlspecialchars($current_user['fname']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="last_name">Last Name:</label>
                                <input type="text" name="last_name" id="last_name" class="form-control" value="<?php echo htmlspecialchars($current_user['lname']); ?>" required>
                            </div>
                            <button type="submit" name="update_info" class="btn btn-primary">Update Information</button>
                        </form>
                    </div>
                    <div class="profile-box mt-4">
                        <h5>Update Profile Picture</h5>
                        <hr class="divider">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="profile_picture">Choose a new profile picture:</label>
                                <input type="file" name="profile_picture" id="profile_picture" class="form-control-file" accept="image/jpeg, image/png">
                            </div>
                            <button type="submit" name="update_picture" class="btn btn-primary">Update Picture</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="feedbackModal" tabindex="-1" aria-labelledby="feedbackModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="feedbackModalLabel">
                                <?php echo ($feedback_type == 'success') ? 'Success' : 'Error'; ?>
                            </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <?php echo htmlspecialchars($feedback_message); ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="changePasswordModal" tabindex="-1" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="changePasswordModalLabel">Change Password</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="change_password.php">
                            <div class="form-group">
                                <label for="current_password">Current Password:</label>
                                <div class="input-group">
                                    <input type="password" id="current_password" name="current_password" class="form-control" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text" onclick="togglePasswordVisibility('current_password')">
                                            <i class="fa fa-eye" id="eye_current"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="new_password">New Password:</label>
                                <div class="input-group">
                                    <input type="password" id="new_password" name="new_password" class="form-control" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text" onclick="togglePasswordVisibility('new_password')">
                                            <i class="fa fa-eye" id="eye_new"></i>
                                        </span>
                                    </div>
                                </div>
                                <div class="progress mt-2">
                                    <div id="passwordStrength" class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">Weak</div>
                                </div>
                                <small id="passwordFeedback" class="form-text text-muted"></small>
                            </div>

                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password:</label>
                                <div class="input-group">
                                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text" onclick="togglePasswordVisibility('confirm_password')">
                                            <i class="fa fa-eye" id="eye_confirm"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">Change Password</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <script>
    function togglePasswordVisibility(passwordFieldId) {
    const passwordField = document.getElementById(passwordFieldId);
    const eyeIcon = document.getElementById('eye_' + passwordFieldId.split('_')[1]);

    if (passwordField.type === 'password') {
        passwordField.type = 'text';
        eyeIcon.classList.remove('fa-eye');
        eyeIcon.classList.add('fa-eye-slash');
    } else {
        passwordField.type = 'password';
        eyeIcon.classList.remove('fa-eye-slash');
        eyeIcon.classList.add('fa-eye');
    }
}
    const passwordField = document.getElementById('new_password');
    const passwordStrength = document.getElementById('passwordStrength');
    const passwordFeedback = document.getElementById('passwordFeedback');
    passwordField.addEventListener('input', function() {
        const password = this.value;
        let strength = 0;
        if (password.length >= 8) strength += 20;
        if (/[A-Z]/.test(password)) strength += 20; 
        if (/[a-z]/.test(password)) strength += 20; 
        if (/[0-9]/.test(password)) strength += 20;
        if (/[\W_]/.test(password)) strength += 20;
        passwordStrength.style.width = strength + '%';
        passwordStrength.setAttribute('aria-valuenow', strength);

        if (strength < 40) {
            passwordStrength.className = 'progress-bar bg-danger'; 
            passwordFeedback.textContent = 'Weak password';
        } else if (strength < 70) {
            passwordStrength.className = 'progress-bar bg-warning';
            passwordFeedback.textContent = 'Moderate password';
        } else {
            passwordStrength.className = 'progress-bar bg-success';
            passwordFeedback.textContent = 'Strong password';
        }
    });
    $(document).ready(function() {
        <?php if ($feedback_message): ?>
            $('#feedbackModal').modal('show');
        <?php endif; ?>
    });
</script>
            <script>
                window.onload = function() {
                    <?php if (!empty($feedback_message)): ?>
                        $('#feedbackModal').modal('show');
                    <?php endif; ?>
                };
            </script>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
