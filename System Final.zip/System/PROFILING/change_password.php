<?php
session_start();
include '../CONNECTION/connection.php';
$user_email = $_SESSION['email'];
$feedback_message = ''; 
$feedback_type = ''; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    $query = "SELECT password, usertype FROM user_table WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $user_email);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($current_hashed_password, $user_type);
        $stmt->fetch();

        if (empty($new_password) || empty($confirm_password)) {
            $feedback_message = 'All fields are required!';
            $feedback_type = 'error';
        } elseif ($new_password !== $confirm_password) {
            $feedback_message = 'New password and confirm password do not match!';
            $feedback_type = 'error';
        } elseif (!preg_match('/[A-Z]/', $new_password)) {
            $feedback_message = 'New password must contain at least one uppercase letter!';
            $feedback_type = 'error';
        } elseif (!preg_match('/[a-z]/', $new_password)) {
            $feedback_message = 'New password must contain at least one lowercase letter!';
            $feedback_type = 'error';
        } elseif (!preg_match('/[0-9]/', $new_password)) {
            $feedback_message = 'New password must contain at least one number!';
            $feedback_type = 'error';
        } elseif (!preg_match('/[\W_]/', $new_password)) {
            $feedback_message = 'New password must contain at least one special character!';
            $feedback_type = 'error';
        } elseif (strlen($new_password) < 8) {
            $feedback_message = 'New password must be at least 8 characters long!';
            $feedback_type = 'error';
        } elseif (password_verify($new_password, $current_hashed_password)) {
            $feedback_message = 'New password cannot be the same as the old password!';
            $feedback_type = 'error';
        } else {
            $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);

            $update_query = "UPDATE user_table SET password = ? WHERE email = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("ss", $hashed_new_password, $user_email);

            if ($update_stmt->execute()) {
                $action = "Change Password";
                $log_query = "INSERT INTO audit_table (email, usertype, action, date_time) VALUES (?, ?, ?, NOW())";
                $log_stmt = $conn->prepare($log_query);
                $log_stmt->bind_param("sss", $user_email, $user_type, $action);
                $log_stmt->execute();

                $feedback_message = 'Password updated successfully!';
                $feedback_type = 'success';
            } else {
                $feedback_message = 'Failed to update password. Please try again!';
                $feedback_type = 'error';
            }
        }
    } else {
        $feedback_message = 'User not found!';
        $feedback_type = 'error';
    }

    $_SESSION['feedback_message'] = $feedback_message;
    $_SESSION['feedback_type'] = $feedback_type;

 
    header('Location: edit_profile.php');
    exit;
}
?>
