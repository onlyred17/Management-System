<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Table</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="../CSS/main.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
    <style>
        .new-table-responsive {
            max-height: 400px; 
            overflow-y: auto; 
        }
        .new-success { background-color: #d4edda; }
        .new-failed { background-color: #f8d7da; }
        .new-change { background-color: #fff3cd; }
        table{
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.10);

        }
        .btn-primary{
            background-color: #007B7F !important;
            color: white !important;
            border: none !important;
    outline: none !important; 
        }
        .btn-primary:hover{
          
            background-color: #005B5D !important;
            color: black !important;

        }
    </style>
</head>
<body>
<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: ../LOGIN/login.php");
    exit();
}

require '../CONNECTION/connection.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userName = "Guest"; 
$userProfilePicture = '../PROFILE/default-profile.png'; 

if (isset($_SESSION['email'])) {
    $auditEmail = $_SESSION['email'];

    $stmt = $conn->prepare("SELECT fname, lname, user_profile_picture FROM user_table WHERE email = ?");
    $stmt->bind_param("s", $auditEmail);
    $stmt->execute();
    $userResult = $stmt->get_result();

    if ($userResult->num_rows > 0) {
        $userData = $userResult->fetch_assoc();
        $userName = $userData['fname'] . ' ' . $userData['lname'];
        $userProfilePicture = $userData['user_profile_picture'] ?: $userProfilePicture; 
    }
}

$sql_recent_activities = "SELECT id, email, action, date_time FROM audit_table ORDER BY date_time DESC"; 
$result_recent_activities = $conn->query($sql_recent_activities);

$sql_actions = "SELECT DISTINCT action FROM audit_table ORDER BY action"; 
$result_actions = $conn->query($sql_actions);
?>
<div class="header">
        <?php include '../HEADER/header.php'; ?>
    </div>
<div class="d-flex flex-wrap">
    <?php include '../SIDEBAR/sidebar.php'; ?>

    <div class="col-md-10 col-12">

        <div class="container mt-4">
            <h1>Audit Table</h1>

            <div class="mb-3">
            <button class="btn btn-primary" id="generateReportButton">Generate Report</button>
            </div>

            <div class="mb-3">
                <label for="actionFilter">Filter by Action:</label>
                <select id="actionFilter" class="form-control" onchange="filterTable()">
                    <option value="">All Actions</option>
                    <?php
                    if ($result_actions && $result_actions->num_rows > 0) {
                        while ($actionRow = $result_actions->fetch_assoc()) {
                            echo "<option value='" . htmlspecialchars($actionRow['action']) . "'>" . htmlspecialchars($actionRow['action']) . "</option>";
                        }
                    }
                    ?>
                </select>
            </div>

            <div class="new-table-responsive">
                <table id="auditTable" class="table table-bordered table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th>User</th>
                            <th>Action</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody id="auditTableBody">
                        <?php
                        if ($result_recent_activities && $result_recent_activities->num_rows > 0) {
                            while ($row = $result_recent_activities->fetch_assoc()) {
                                $rowClass = '';
                                switch ($row['action']) {
                                    case 'Login Success':
                                        $rowClass = 'new-success';
                                        break;
                                    case 'Login Failed':
                                        $rowClass = 'new-failed';
                                        break;
                                    case 'Change Settings':
                                        $rowClass = 'new-change';
                                        break;
                                    default:
                                        $rowClass = '';
                                }

                                echo "<tr class='$rowClass' onclick=\"showDetails('" . htmlspecialchars($row['email']) . "', '" . htmlspecialchars($row['action']) . "', '" . htmlspecialchars($row['date_time']) . "', '" . htmlspecialchars($userData['fname']) . "', '" . htmlspecialchars($userData['lname']) . "', '" . htmlspecialchars($userProfilePicture) . "')\" style='cursor: pointer;'>";
                                echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['action']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['date_time']) . "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='4' class='text-center'>No recent activities found.</td></tr>"; 
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="modal fade" id="detailsModal" tabindex="-1" aria-labelledby="detailsModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="detailsModalLabel">Activity Details</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body text-center">
                        <img id="modalProfilePicture" src="" alt="Profile Picture" class="img-fluid rounded-circle mb-3" style="width: 120px; height: 120px; border: 2px solid #83B4FF;">
                        <h6 class="font-weight-bold">User Information</h6>
                        <p><strong>Name:</strong> <span id="modalName"></span></p>
                        <p><strong>User:</strong> <span id="modalEmail"></span></p>
                        <hr>
                        <h6 class="font-weight-bold">Activity Details</h6>
                        <p><strong>Action:</strong> <span id="modalAction"></span></p>
                        <p><strong>Date:</strong> <span id="modalDate"></span></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="deleteConfirmationModal" tabindex="-1" aria-labelledby="deleteConfirmationModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirm Deletion</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body text-center">
                        <p>Are you sure you want to delete this activity?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-danger" id="confirmDeleteButton">Delete</button>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
        <script>
            let deleteId; 

            $(document).ready(function() {
                $('#auditTable').DataTable();

                window.showDetails = function(email, action, date, firstName, lastName, profilePicture) {
                    $('#modalProfilePicture').attr('src', profilePicture);
                    $('#modalName').text(firstName + ' ' + lastName);
                    $('#modalEmail').text(email);
                    $('#modalAction').text(action);
                    $('#modalDate').text(date);
                    $('#detailsModal').modal('show');
                };

                window.filterTable = function() {
                    var actionFilter = $('#actionFilter').val();
                    $('#auditTable').DataTable().column(1).search(actionFilter).draw();
                };

                window.confirmDelete = function(event, id) {
                    event.stopPropagation();
                    deleteId = id;
                    $('#deleteConfirmationModal').modal('show');
                };

                $('#confirmDeleteButton').click(function() {
                    if (deleteId) {
                        $.ajax({
                            url: 'delete_audit.php',
                            type: 'POST',
                            data: { id: deleteId },
                            success: function(response) {
                                location.reload(); 
                            }
                        });
                    }
                });
            });
            $(document).ready(function() {
        var table = $('#auditTable').DataTable();

        $('#generateReportButton').click(function() {
            var actionFilter = $('#actionFilter').val(); 
            var searchTerm = table.search();
            var url = '../AUDIT_TRAIL/generate_report.php';
            if (actionFilter) {
                url += '?action=' + encodeURIComponent(actionFilter);
            }

        
            if (searchTerm) {
                url += (actionFilter ? '&' : '?') + 'search=' + encodeURIComponent(searchTerm);
            }

            window.open(url, '_blank'); 
        });
        });
        </script>
    </div>
</div>
</body>
</html>
