<?php
session_start();
require '../CONNECTION/connection.php'; 


if (isset($_SESSION['email'])) {
    $auditEmail = $_SESSION['email'];

 
    $stmt = $conn->prepare("SELECT usertype FROM user_table WHERE email = ?"); 
    $stmt->bind_param("s", $auditEmail);
    $stmt->execute();
    $stmt->bind_result($userType);
    $stmt->fetch(); 

    $stmt->close();
   
    if ($userType) { 
        $stmt = $conn->prepare("INSERT INTO audit_table (email, action, usertype, date_time) VALUES (?, ?, ?, NOW())");
        $action = 'LOGGED OUT';
        $stmt->bind_param("sss", $auditEmail, $action, $userType); 
        
        if ($stmt->execute()) {
        } else {
        }
        
     
        $stmt->close();
        
        session_unset();
        session_destroy();
        header("Location: ../LOGIN/login.php");
        exit();
    } else {
      
        echo "User type not found.";
        exit();
    }
} else {
    header("Location: ../LOGIN/login.php");
    exit();
}
?>
